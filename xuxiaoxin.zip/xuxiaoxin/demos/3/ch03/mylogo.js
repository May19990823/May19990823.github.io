"use strict";
var canvas;
var gl;
